Channels Examples
=================

This is a repository of simple, well-commented examples of how to implement a
few different site features in Django Channels.

Each example is a standalone Django project; instructions for running them
are in their own README files.

Pull requests of whole new examples, or small improvements to existing ones,
are welcome; however, they should still be simple and not add too many complex
features or additional steps to running it.
