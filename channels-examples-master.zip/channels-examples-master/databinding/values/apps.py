from django.apps import AppConfig


class ValuesConfig(AppConfig):
    name = 'values'
