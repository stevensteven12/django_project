# Django Graph Plotter

### How to install ?

* First fork the repo and then clone it on local machine.
* Create a Virtual environment and install the dependencies.

```
pip install -r requirements.txt
```

### How to Use?

* In Function field enter polynomial equation f(x) like **x*2 + 4**.
* In Domain , enter the range of values of x seperated by space like **10 30**.


**Digital Artist Prateek**

http://askprateek.com 


