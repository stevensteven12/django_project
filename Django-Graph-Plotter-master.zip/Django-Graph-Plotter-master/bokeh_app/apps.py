from django.apps import AppConfig


class BokehConfig(AppConfig):
    name = 'bokeh'
